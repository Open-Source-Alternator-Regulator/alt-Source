# Libraries
This folder contains snapshots of the supporting libraries used to compile releases of the Alternator Regulator

3rd party libraries change over time, occasionally creating issues (example, the NMEA2000 lib has grown in side and causes the regulator to exceed max code size).   For these reasons I have taken a snap-shot of the libs I use and copied them here.

