These are some unit tests for new methods

To test on a PC:

   c++ -I. testTypes.cpp -o testTypes
   ./testTypes
