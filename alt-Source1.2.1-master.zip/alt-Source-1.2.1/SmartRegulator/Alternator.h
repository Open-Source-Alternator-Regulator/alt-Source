//      Alternator.h
//
//      Copyright (c) 2016, 2017, 2018 by William A. Thomason.      http://arduinoalternatorregulator.blogspot.com/
//
//
//
//              This program is free software: you can redistribute it and/or modify
//              it under the terms of the GNU General Public License as published by
//              the Free Software Foundation, either version 3 of the License, or
//              (at your option) any later version.
//      
//              This program is distributed in the hope that it will be useful,
//              but WITHOUT ANY WARRANTY; without even the implied warranty of
//              MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//              GNU General Public License for more details.
//      
//              You should have received a copy of the GNU General Public License
//              along with this program.  If not, see <http://www.gnu.org/licenses/>.
//
//


#ifndef _ALTERNATOR_H_
#define _ALTERNATOR_H_

#include "Config.h"
#include "CPE.h" 


typedef enum tModes {unknown, disabled, FAULTED, FAULTED_REDUCED_LOAD,                                                          // Used by most or all  (0..3)
                     pending_R, ramping, determine_ALT_cap, bulk_charge, acceptance_charge, overcharge_charge, float_charge, forced_float_charge, post_float, equalize, RBM_CVCC,
                                                                                                                                // Alternator / Charger Mode specific (4..14)
                                                                                                                                //  (BMS uses a subset for chargerMode, keeping order to simplify external ASCII apps.)
                     discharge, recharge, LTStore, holdSOC, sph1, sph2, sph3, sph4, sph5, sph6, sph7,                           // BatMon specific  (15..18, 19..25=SpaceHolders)
                     sleeping, stopped, stopping, starting, warming, running, priming_oil                                       // Generator engine specific  (26..32)
                    } tModes;                                                                                                   // Take care not to change the order of these, some tests use
                                                                                                                                // things like <= pending_R






extern volatile unsigned int    interuptCounter;
extern volatile bool            statorIRQflag;
extern unsigned long            lastPWMChanged;
extern unsigned long            altModeChanged; 
extern unsigned long            EORLastReceived; 
extern tModes                   chargingState;
extern int      altCapAmps;
extern int      altCapRPMs;

extern int      targetAltWatts;
extern float    targetBatVolts;
extern float    targetBatAmps;
extern float    targetAltAmps;
extern int      measuredRPMs;
extern bool     smallAltMode;
extern bool     tachMode;
extern int      fieldPWMvalue; 
extern int      thresholdPWMvalue;
extern bool     usingEXTAmps; 
extern float    persistentBatAmps;
extern float    persistentBatVolts;

extern tCPS     chargingParms;
extern tSCS     systemConfig;

extern float    systemVoltMult;
extern float    systemAmpMult;
extern uint8_t  cpIndex;


#ifdef CPU_STM32
  extern "C"                                                                    //  STM32 mixes C and CPP calling conventions, stator_IRQ() callback needs to be in "C" form.
  #endif
  void stator_IRQ(void); 

void calculate_RPMs(void);
void calculate_ALT_targets(void);
void set_charging_mode(tModes settingMode);
void set_ALT_PWM(int  PWM);
void manage_ALT(void);
bool initialize_alternator(void);

#ifdef SYSTEMCAN 
 uint8_t ALT_Per_Util(void);
 #endif


#endif  // _ALTERNATOR_H_


