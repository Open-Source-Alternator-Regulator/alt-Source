This snapshot of the NEMA2000 lib has been edited to reduce its size.

It is a subset of the true NMEA2000 lib, and is intended to be used 
with the Arduino Alternator Regualtor project.


Look for //!! in the soruce code for changes made.