Free Memory code from:

http://arduino.cc/playground/Code/AvailableMemory

